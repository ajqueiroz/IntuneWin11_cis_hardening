﻿# CIS Microsoft Intune for Windows 11 Benchmark v5.0.0 - section 82 (System Services)
# Intune Remediation. Upload as a pair: Detect-CIS-Services.ps1 (detection) + Remediate-CIS-Services.ps1 (remediation).
# Settings: Run as SYSTEM = Yes (default), 64-bit PowerShell = Yes, signature check = No. Schedule: daily.
# Level 1 = 16 services. Level 2 = 20 more services, OFF by default
# because they include Print Spooler, Remote Desktop, Server (file sharing), WinRM, Bluetooth and Windows Error Reporting.
# To add Level 2: set $IncludeLevel2 = $true in BOTH scripts.

$IncludeLevel2 = $false

$Level1 = @(
    @{ Cis = '82.3'; Name = 'Browser'; Display = 'Computer Browser (Browser)' },
    @{ Cis = '82.7'; Name = 'IISADMIN'; Display = 'IIS Admin Service (IISADMIN)' },
    @{ Cis = '82.8'; Name = 'irmon'; Display = 'Infrared monitor service (irmon)' },
    @{ Cis = '82.10'; Name = 'LxssManager'; Display = 'LxssManager (LxssManager)' },
    @{ Cis = '82.11'; Name = 'FTPSVC'; Display = 'Microsoft FTP Service (FTPSVC)' },
    @{ Cis = '82.13'; Name = 'sshd'; Display = 'OpenSSH SSH Server (sshd)' },
    @{ Cis = '82.20'; Name = 'RpcLocator'; Display = 'Remote Procedure Call (RPC) Locator (RpcLocator)' },
    @{ Cis = '82.22'; Name = 'RemoteAccess'; Display = 'Routing and Remote Access (RemoteAccess)' },
    @{ Cis = '82.24'; Name = 'simptcp'; Display = 'Simple TCP/IP Services (simptcp)' },
    @{ Cis = '82.26'; Name = 'sacsvr'; Display = 'Special Administration Console Helper (sacsvr)' },
    @{ Cis = '82.27'; Name = 'SSDPSRV'; Display = 'SSDP Discovery (SSDPSRV)' },
    @{ Cis = '82.28'; Name = 'upnphost'; Display = 'UPnP Device Host (upnphost)' },
    @{ Cis = '82.29'; Name = 'WMSvc'; Display = 'Web Management Service (WMSvc)' },
    @{ Cis = '82.32'; Name = 'WMPNetworkSvc'; Display = 'Windows Media Player Network Sharing Service (WMPNetworkSvc)' },
    @{ Cis = '82.33'; Name = 'icssvc'; Display = 'Windows Mobile Hotspot Service (icssvc)' },
    @{ Cis = '82.36'; Name = 'W3SVC'; Display = 'World Wide Web Publishing Service (W3SVC)' }
)
$Level2 = @(
    @{ Cis = '82.1'; Name = 'BTAGService'; Display = 'Bluetooth Audio Gateway Service (BTAGService)' },
    @{ Cis = '82.2'; Name = 'bthserv'; Display = 'Bluetooth Support Service (bthserv)' },
    @{ Cis = '82.4'; Name = 'MapsBroker'; Display = 'Downloaded Maps Manager (MapsBroker)' },
    @{ Cis = '82.5'; Name = 'GameInputSvc'; Display = 'GameInput Service (GameInputSvc)' },
    @{ Cis = '82.6'; Name = 'lfsvc'; Display = 'Geolocation Service (lfsvc)' },
    @{ Cis = '82.9'; Name = 'lltdsvc'; Display = 'Link-Layer Topology Discovery Mapper (lltdsvc)' },
    @{ Cis = '82.12'; Name = 'MSiSCSI'; Display = 'Microsoft iSCSI Initiator Service (MSiSCSI)' },
    @{ Cis = '82.14'; Name = 'Spooler'; Display = 'Print Spooler (Spooler)' },
    @{ Cis = '82.15'; Name = 'wercplsupport'; Display = 'Problem Reports and Solutions Control Panel Support (wercplsupport)' },
    @{ Cis = '82.16'; Name = 'RasAuto'; Display = 'Remote Access Auto Connection Manager (RasAuto)' },
    @{ Cis = '82.17'; Name = 'SessionEnv'; Display = 'Remote Desktop Configuration (SessionEnv)' },
    @{ Cis = '82.18'; Name = 'TermService'; Display = 'Remote Desktop Services (TermService)' },
    @{ Cis = '82.19'; Name = 'UmRdpService'; Display = 'Remote Desktop Services UserMode Port Redirector (UmRdpService)' },
    @{ Cis = '82.21'; Name = 'RemoteRegistry'; Display = 'Remote Registry (RemoteRegistry)' },
    @{ Cis = '82.23'; Name = 'LanmanServer'; Display = 'Server (LanmanServer)' },
    @{ Cis = '82.25'; Name = 'SNMP'; Display = 'SNMP Service (SNMP)' },
    @{ Cis = '82.30'; Name = 'WerSvc'; Display = 'Windows Error Reporting Service (WerSvc)' },
    @{ Cis = '82.31'; Name = 'Wecsvc'; Display = 'Windows Event Collector (Wecsvc)' },
    @{ Cis = '82.34'; Name = 'PushToInstall'; Display = 'Windows PushToInstall Service (PushToInstall)' },
    @{ Cis = '82.35'; Name = 'WinRM'; Display = 'Windows Remote Management (WS-Management) (WinRM)' }
)
$Services = if ($IncludeLevel2) { $Level1 + $Level2 } else { $Level1 }

$problems = @()
foreach ($s in $Services) {
    $svc = Get-Service -Name $s.Name -ErrorAction SilentlyContinue
    if ($null -eq $svc) { continue }                       # "Not Installed" is compliant
    if ($svc.StartType -ne 'Disabled') { $problems += "$($s.Cis) $($s.Name) start type is $($svc.StartType)" }
}
if ($problems.Count -gt 0) {
    Write-Output ("Not compliant: " + ($problems -join '; '))
    exit 1
}
Write-Output "Compliant: all CIS services are Disabled or not installed"
exit 0
