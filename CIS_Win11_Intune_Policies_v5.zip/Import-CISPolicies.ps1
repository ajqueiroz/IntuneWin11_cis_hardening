<#
.SYNOPSIS
  Imports the CIS Windows 11 (v5.0.0) and Defender Antivirus (v1.0.0) Intune policies in this folder.

.DESCRIPTION
  - SettingsCatalog\*.json   -> Devices > Configuration (Settings Catalog)
  - CompliancePolicies\*.json -> Devices > Compliance
  - Remediation\*.ps1        -> Devices > Scripts and remediations > Remediations
  Nothing is assigned. Policies whose name already exists are skipped (never overwritten).
  The "Organisation Settings (EDIT BEFORE IMPORT)" policy is skipped while it still contains CHANGE-ME values.

.PARAMETER TenantId
  Your Microsoft Entra tenant ID.

.PARAMETER WhatIf
  Show what would be imported without creating anything.

.EXAMPLE
  .\Import-CISPolicies.ps1 -TenantId 00000000-0000-0000-0000-000000000000 -WhatIf
  .\Import-CISPolicies.ps1 -TenantId 00000000-0000-0000-0000-000000000000
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$TenantId,
    [switch]$WhatIf,
    [switch]$SkipLevel2,
    [switch]$SkipBitLocker
)

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot

if (-not (Get-Module -ListAvailable -Name Microsoft.Graph.Authentication)) {
    Write-Host "Installing Microsoft.Graph.Authentication for the current user..." -ForegroundColor Yellow
    Install-Module Microsoft.Graph.Authentication -Scope CurrentUser -Force
}
Import-Module Microsoft.Graph.Authentication

Connect-MgGraph -TenantId $TenantId -NoWelcome -Scopes 'DeviceManagementConfiguration.ReadWrite.All', 'DeviceManagementScripts.ReadWrite.All'

function Get-AllNames([string]$Uri, [string]$Property) {
    $names = @{}
    $next = $Uri
    while ($next) {
        $r = Invoke-MgGraphRequest -Method GET -Uri $next
        foreach ($v in $r.value) { $names[$v.$Property] = $true }
        $next = $r.'@odata.nextLink'
    }
    return $names
}

$base = 'https://graph.microsoft.com/beta/deviceManagement'
$existingSC = Get-AllNames "$base/configurationPolicies?`$select=name" 'name'
$existingCP = Get-AllNames "$base/deviceCompliancePolicies?`$select=displayName" 'displayName'
$existingRS = Get-AllNames "$base/deviceHealthScripts?`$select=displayName" 'displayName'
$results = @()

# ---------------- Settings Catalog
foreach ($f in Get-ChildItem (Join-Path $root 'SettingsCatalog') -Filter *.json | Sort-Object Name) {
    $raw = Get-Content $f.FullName -Raw
    $obj = $raw | ConvertFrom-Json
    if ($SkipLevel2 -and $obj.name -match ' - L2 - ') { $results += [pscustomobject]@{Policy=$obj.name; Result='Skipped (-SkipLevel2)'}; continue }
    if ($SkipBitLocker -and $obj.name -match ' - BL - ') { $results += [pscustomobject]@{Policy=$obj.name; Result='Skipped (-SkipBitLocker)'}; continue }
    if ($raw -match 'CHANGE-ME') { $results += [pscustomobject]@{Policy=$obj.name; Result='Skipped - edit the CHANGE-ME values first'}; continue }
    if ($existingSC.ContainsKey($obj.name)) { $results += [pscustomobject]@{Policy=$obj.name; Result='Skipped - already exists'}; continue }
    if ($WhatIf) { $results += [pscustomobject]@{Policy=$obj.name; Result='Would import'}; continue }
    try {
        Invoke-MgGraphRequest -Method POST -Uri "$base/configurationPolicies" -Body $raw -ContentType 'application/json' | Out-Null
        $results += [pscustomobject]@{Policy=$obj.name; Result='Imported'}
    }
    catch { $results += [pscustomobject]@{Policy=$obj.name; Result="FAILED: $($_.ErrorDetails.Message)"} }
}

# ---------------- Compliance
foreach ($f in Get-ChildItem (Join-Path $root 'CompliancePolicies') -Filter *.json) {
    $raw = Get-Content $f.FullName -Raw
    $obj = $raw | ConvertFrom-Json
    if ($existingCP.ContainsKey($obj.displayName)) { $results += [pscustomobject]@{Policy=$obj.displayName; Result='Skipped - already exists'}; continue }
    if ($WhatIf) { $results += [pscustomobject]@{Policy=$obj.displayName; Result='Would import'}; continue }
    try {
        Invoke-MgGraphRequest -Method POST -Uri "$base/deviceCompliancePolicies" -Body $raw -ContentType 'application/json' | Out-Null
        $results += [pscustomobject]@{Policy=$obj.displayName; Result='Imported'}
    }
    catch { $results += [pscustomobject]@{Policy=$obj.displayName; Result="FAILED: $($_.ErrorDetails.Message)"} }
}

# ---------------- Remediation (services)
$rName = 'CIS W11 v5 - System Services (section 82)'
if ($existingRS.ContainsKey($rName)) { $results += [pscustomobject]@{Policy=$rName; Result='Skipped - already exists'} }
elseif ($WhatIf) { $results += [pscustomobject]@{Policy=$rName; Result='Would import'} }
else {
    $det = [Convert]::ToBase64String([IO.File]::ReadAllBytes((Join-Path $root 'Remediation\Detect-CIS-Services.ps1')))
    $rem = [Convert]::ToBase64String([IO.File]::ReadAllBytes((Join-Path $root 'Remediation\Remediate-CIS-Services.ps1')))
    $body = @{
        displayName = $rName; description = 'CIS Microsoft Intune for Windows 11 Benchmark v5.0.0 section 82: disables the listed services (Level 1 by default).'
        publisher = 'IT Security'; runAsAccount = 'system'; runAs32Bit = $false; enforceSignatureCheck = $false
        detectionScriptContent = $det; remediationScriptContent = $rem; roleScopeTagIds = @('0')
    } | ConvertTo-Json
    try {
        Invoke-MgGraphRequest -Method POST -Uri "$base/deviceHealthScripts" -Body $body -ContentType 'application/json' | Out-Null
        $results += [pscustomobject]@{Policy=$rName; Result='Imported (assign it with a daily schedule)'}
    }
    catch { $results += [pscustomobject]@{Policy=$rName; Result="FAILED: $($_.ErrorDetails.Message)"} }
}

$results | Format-Table -AutoSize -Wrap
Write-Host "`nNothing has been assigned. Assign to a pilot group first." -ForegroundColor Cyan
Disconnect-MgGraph | Out-Null
